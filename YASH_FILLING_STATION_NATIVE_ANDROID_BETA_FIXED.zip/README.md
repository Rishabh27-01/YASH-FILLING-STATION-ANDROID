# YASH FILLING STATION — Native Android Beta Foundation

Native Kotlin Android app, no WebView. Implements Supabase email/password sign-in and profile role/approval checks.

## Why this package exists
The saved GitHub Actions workflow referenced `YASH-FILLING-STATION-NEXT-LEVEL-SEPARATE-APP.zip`, but that ZIP/native source was not present in the saved files I could locate. This is a clean reproducible native foundation, not a claim that the missing project was recovered.

## Build
GitHub Actions workflow: `.github/workflows/build-apk.yml`
Build command: `gradle --no-daemon :app:assembleDebug`
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Backend
URL: `https://dgxkwkzphdvzqyrpgxug.supabase.co`
Uses the public publishable key only. Never embed a service-role key in a mobile app.
Requires `public.profiles` fields `id`, `full_name`, `role`, `status`, `is_active`, `username`, with RLS permitting an authenticated user to read their own profile.

## Not production-ready
Only authentication and profile gating are implemented. Do not use for live fuel/cash accounting until sales, nozzle readings, shift reconciliation, testing, stock/dips, fuel deliveries, credit, expenses, reports, staff approvals and audit logs are implemented and tested.

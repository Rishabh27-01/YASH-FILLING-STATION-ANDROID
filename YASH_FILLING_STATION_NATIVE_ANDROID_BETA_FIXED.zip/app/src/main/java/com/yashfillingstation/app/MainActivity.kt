package com.yashfillingstation.app

import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private val supabaseUrl = "https://dgxkwkzphdvzqyrpgxug.supabase.co"
    // Public publishable key only. Never embed a service-role key in an app.
    private val publishableKey = "sb_publishable_qXR31pN3z5cgHpO3sKYSbg__UvOWZhY"
    private val http = OkHttpClient()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }

    private fun layout() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(android.graphics.Color.rgb(244,247,250))
        }
        setContentView(root)
    }
    private fun showLogin() {
        layout()
        root.addView(TextView(this).apply {
            text="⛽  YASH FILLING STATION"; textSize=24f; gravity=Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(7,85,160))
        }, lp())
        root.addView(TextView(this).apply {
            text="Native Android • Supabase authentication"; textSize=14f; gravity=Gravity.CENTER
        }, lp())
        val role = Spinner(this)
        role.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Admin / Owner","Employee"))
        root.addView(role, lp())
        val email = EditText(this).apply { hint="Account email"; inputType= android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; setSingleLine(true) }
        root.addView(email, lp())
        val password = EditText(this).apply { hint="Password"; inputType= android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; setSingleLine(true) }
        root.addView(password, lp())
        val status = TextView(this).apply { textSize=14f }
        root.addView(status, lp())
        val button = Button(this).apply { text="Login" }
        root.addView(button, lp())
        button.setOnClickListener {
            val e=email.text.toString().trim(); val p=password.text.toString()
            if(e.isBlank() || p.isBlank()){ status.text="Enter email and password."; return@setOnClickListener }
            button.isEnabled=false; status.text="Connecting securely to Supabase…"
            lifecycleScope.launch {
                try {
                    val pair=withContext(Dispatchers.IO){ signIn(e,p) }
                    val profile=withContext(Dispatchers.IO){ loadProfile(pair.first,pair.second) }
                    val wanted=if(role.selectedItemPosition==0) "admin" else "employee"
                    if(profile.optString("status").lowercase() !in listOf("approved","active"))
                        throw IOException("Account is pending Admin approval or inactive.")
                    if(!profile.optBoolean("is_active",true)) throw IOException("This account is inactive. Contact Admin.")
                    if(profile.optString("role")!=wanted) throw IOException("Selected role does not match this account.")
                    showDashboard(profile.optString("full_name").ifBlank { e },wanted)
                } catch(ex:Exception) {
                    status.text=ex.message ?: "Login failed. Check internet and account details."
                } finally { button.isEnabled=true }
            }
        }
    }
    private fun signIn(email:String,password:String):Pair<String,String> {
        val body=JSONObject().put("email",email).put("password",password)
        val req=Request.Builder().url("$supabaseUrl/auth/v1/token?grant_type=password")
            .addHeader("apikey",publishableKey).addHeader("Content-Type","application/json")
            .post(body.toString().toRequestBody(jsonType)).build()
        http.newCall(req).execute().use { r ->
            val text=r.body?.string().orEmpty()
            if(!r.isSuccessful) {
                val message=runCatching { JSONObject(text).optString("msg").ifBlank { JSONObject(text).optString("message") } }.getOrNull()
                throw IOException(message?.takeIf{it.isNotBlank()} ?: "Supabase sign-in failed (HTTP ${r.code}).")
            }
            val data=JSONObject(text)
            return data.getString("access_token") to data.getJSONObject("user").getString("id")
        }
    }
    private fun loadProfile(token:String,userId:String):JSONObject {
        val req=Request.Builder()
            .url("$supabaseUrl/rest/v1/profiles?id=eq.$userId&select=full_name,role,status,is_active,username")
            .addHeader("apikey",publishableKey).addHeader("Authorization","Bearer $token").get().build()
        http.newCall(req).execute().use { r ->
            val text=r.body?.string().orEmpty()
            if(!r.isSuccessful) throw IOException("Profile lookup failed (HTTP ${r.code}).")
            val rows=org.json.JSONArray(text)
            if(rows.length()==0) throw IOException("Profile not found. Contact Admin.")
            return rows.getJSONObject(0)
        }
    }
    private fun showDashboard(name:String,role:String) {
        layout()
        root.addView(TextView(this).apply { text="YASH FILLING STATION"; textSize=23f; setTextColor(android.graphics.Color.rgb(7,85,160)) },lp())
        root.addView(TextView(this).apply { text="Welcome, $name • ${role.uppercase()}"; textSize=16f },lp())
        root.addView(TextView(this).apply {
            text="Supabase sign-in succeeded.\n\nThis beta is only the native Android authentication foundation. Sales/nozzle readings, shift reconciliation, testing, stock/dips, fuel loads, credit, expenses, reports, employee management and audit modules still need verified database integration and testing before operational use."
            textSize=15f; setPadding(0,dp(12),0,dp(12))
        },lp())
        root.addView(Button(this).apply { text="Logout"; setOnClickListener { showLogin() } },lp())
    }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun lp()=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin=dp(10) }
}

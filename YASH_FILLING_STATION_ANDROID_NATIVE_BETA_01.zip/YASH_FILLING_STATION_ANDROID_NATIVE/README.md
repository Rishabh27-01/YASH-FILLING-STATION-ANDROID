# YASH FILLING STATION — Native Android Foundation
Native Android app (no WebView). First acceptance gate: real Supabase Admin login -> Dashboard.
Supabase credentials are the public publishable key only; no service-role key is included.
